const pointsToPlot = [
  { id: "A", label: "A", x: 3, y: 6 },
  { id: "B", label: "B", x: 5, y: 9 },
  { id: "C", label: "C", x: 6, y: 0 },
  { id: "D", label: "D", x: 0, y: 2 },
  { id: "E", label: "E", x: -2, y: -5 },
  { id: "F", label: "F", x: 0, y: 0 },
];

let currentPointIndex = 0;
let attempts = 0;
let selectedPoint = 0;

const canvas = document.getElementById("cartesian-plane");
const ctx = canvas.getContext("2d");
// Drawcartesian plane of  the  x and y axes
function drawCartesianPlane() {

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = "#000";
  ctx.beginPath(),ctx.moveTo(300, 0),ctx.lineTo(300, 600), ctx.moveTo(0, 300) ,ctx.lineTo(600, 300) ,ctx.stroke();

  // It Display grid lines to plot
  ctx.strokeStyle = "#ddd";
  for (let i = 0; i <= 600; i += 30) {

    ctx.beginPath(),ctx.moveTo(i, 0), ctx.lineTo(i, 600) ,ctx.moveTo(0, i), ctx.lineTo(600, i), ctx.stroke();

  }

  // Draw labels like(123 and -1-2-3 graph 4quadrents)
  ctx.fillStyle = "red", ctx.font = "12px Arial";
  for (let i = -10; i <= 10; i++) {

    if (i !== 0) {

      ctx.fillText(i, 300 + i * 30 - 5, 310); // X-axis
      ctx.fillText(+i, 290, 305 - i * 30 + 5); // Y-axis

    }
  }
}

// Highlight a point
function plotPoint(x, y, label, correct = true) {

  const canvasX = 300 + x * 30;
  const canvasY = 300 - y * 30;

  ctx.beginPath();
  ctx.arc(canvasX, canvasY, 5, 0, 2 * Math.PI);
  ctx.fillStyle = correct ? "green" : "red";
  ctx.fill();
  ctx.fillText(label, canvasX + 10, canvasY - 10);
}

// initaly shows the Handle button clicks
document.getElementById("controls").addEventListener("click", (e) => {

  if (e.target.tagName === "BUTTON" && !e.target.disabled) {

    selectedPoint = pointsToPlot.find((p) => p.id === e.target.id);
    document.getElementById("feedback").textContent = `Selected ${selectedPoint.label}`;

  }
});

// It will showsHandle canvas clicks events
canvas.addEventListener("click", (e) => {

  if (!selectedPoint) return window.alert(document.getElementById("feedback").textContent = "Please Select the Cartesian value  to Plot : Like (0.0)...");

  const rect = canvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;
  const clickedX = Math.round((mouseX - 300) / 30);
  const clickedY = Math.round((300 - mouseY) / 30);

  if (clickedX === selectedPoint.x && clickedY === selectedPoint.y) {

    plotPoint(clickedX, clickedY, selectedPoint.label);
    window.alert(document.getElementById("feedback").textContent = "सही!");
    document.getElementById(selectedPoint.id).disabled = true;

    // Enable the next button to plot the graph
    currentPointIndex++;
    if (currentPointIndex < pointsToPlot.length) {

      document.getElementById(pointsToPlot[currentPointIndex].id).disabled = false;

    }

    selectedPoint = null;
    attempts = 0;

  } else {

    attempts++;
    if (attempts >= 3) {

      plotPoint(selectedPoint.x, selectedPoint.y, selectedPoint.label, true);
      window.alert(document.getElementById("feedback").textContent = `गलत! सही उत्तर: (${selectedPoint.x}, ${selectedPoint.y})`);
      document.getElementById(selectedPoint.id).disabled = true;

      // Enable next button to plot the graph
      currentPointIndex++;
      if (currentPointIndex < pointsToPlot.length) {

        document.getElementById(pointsToPlot[currentPointIndex].id).disabled = false;

      }

      selectedPoint = null;
      attempts = 0;
    } else {
      window.alert(document.getElementById("feedback").textContent = "गलत! फिर से प्रयास करें।");
    }
  }
});

// Initializes  the Cartesian plane
drawCartesianPlane();
document.getElementById(pointsToPlot[0].id).disabled = false;
